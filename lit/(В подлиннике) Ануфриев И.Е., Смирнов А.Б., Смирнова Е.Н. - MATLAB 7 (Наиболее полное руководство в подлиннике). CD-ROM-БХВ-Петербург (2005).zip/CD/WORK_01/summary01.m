1 + 2
%%
ans/4.5
%%
100/3
%%
100000/3
%%
1/3000
%%
10 e9
%%
help format
%%
format long e
 1.25/3.11
%%
%�������� � ������
FORMAT LONG E
%%
exp(-2.5)*log(11.3)^0.3-sqrt((sin(2.45*pi)+cos(3.78*pi))/tan(3.3))
%%
exp(-2.5)*log(11.3)^0.3+((sin(2.45*pi)+cos(3.78*pi))/tan(3.3))^2
%%
format long e
exp(-2.5)*log(11.3)^0.3-sqrt((sin(2.45*pi)+cos(3.78*pi))/tan(3.3))
%%
format short
ans
%%
1/0
%%
0/0
%%
sqrt(-1.0)
%%
(2.1+3.2i)*2 + (4.2+1.7i)^2
%%
2.1+3.2i*2 + 4.2+1.7i^2
%%
2-3i'
%%
((3.2+1.5i)*2+4.2+7.9i)'
%%
sin(2+3i)
%%
nextpow2(1000)
%%
complex(2.3, 5.8)
%%
z = 1.45
%%
x = sin(1.3*pi)/log(3.4);
y = sqrt(tan(2.75)/tanh(2.75));
z = (x+y)/(x-y)
%%
sin(1.3*pi)/log(3.4)+sqrt(tan(2.75)/tanh(2.75)))/(sin(1.3*pi)/...
log(3.4)-sqrt(tan(2.75)/tanh(2.75)))
%%
(x-y)^(3/2)
%%
t = exp(3.5)
%%
save work20-01-04
%%
load work20-01-04
%%
diary d20-01-04.txt
a1 = 3;
a2 = 2.5;
a3 = a1 + a2
save work20-01-04
quit
%%
who
%%
whos
%%
clear a1 a3
who
%%
pi=sin(3)
%%
z=cos(pi)
%%
exist('d7')
%%
exist('max')
exist('for')
exist('pi')
exist('fzero')
