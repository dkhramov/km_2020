%% Calculation of the integral
% $$\int_{-1}^1 |x|^{-\frac{1}{100}}dx = \frac{200}{99}$$
%% First step. Introduce integrand.
fun=inline('abs(x).^-0.01');
%% Second step. Direct integration using |quadl|
I=quadl(fun,-1,1)
%%
% *It is not very good idea!*
%% Just look at integrand
fplot(fun,[-1 1])
%% Splitting
% $$\int_{-1}^1 |x|^{-\frac{1}{100}}dx = $$
% $$ \int_{-1}^0 (-x)^{-\frac{1}{100}}dx+\int_0^1 x^{-\frac{1}{100}}dx$$
%% First integral 
% $$ \int_{-1}^0 (-x)^{-\frac{1}{100}}dx$$
fplot(fun,[-1 0])
I1=quadl(fun,-1,0)
%% Second integral 
% $$ \int_0^1 x^{-\frac{1}{100}}dx$$
fplot(fun,[0 1])
I2=quadl(fun,0,1)
%% Result 
I=I1+I2
Iex=200/99

