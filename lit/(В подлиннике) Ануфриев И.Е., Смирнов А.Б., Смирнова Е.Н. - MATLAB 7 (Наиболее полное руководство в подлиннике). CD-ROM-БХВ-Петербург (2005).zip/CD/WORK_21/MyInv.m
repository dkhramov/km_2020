Function MyInv(Mrange, IMrange)
MLPutMatrix "M", Mrange
MLEvalString "IM=inv(M)"
MLGetMatrix "IM", IMrange
End Function
