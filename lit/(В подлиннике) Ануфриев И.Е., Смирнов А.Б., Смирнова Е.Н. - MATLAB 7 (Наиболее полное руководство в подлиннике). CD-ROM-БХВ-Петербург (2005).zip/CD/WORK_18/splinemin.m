x=-1.0:0.2:1.0;
fun=inline('exp(-x.^2)');
y=fun(x);
s=csapi(x, y);
[mval,mx]=fnmin(s,[-1 0.5])
