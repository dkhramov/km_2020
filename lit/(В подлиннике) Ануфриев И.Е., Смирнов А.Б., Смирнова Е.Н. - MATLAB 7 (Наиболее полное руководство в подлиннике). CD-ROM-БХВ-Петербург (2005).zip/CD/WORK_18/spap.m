yy=[0    0.25  1  1 0.25  -1 0];
xxx=[-1  -0.5 -0.5 0 0.5 0.5   1];
knots=[-1 -1 -1  -0.5 0 0  0.5 1 1 1];
s=spapi(knots,xxx,yy)
fnplt(s)


 x=(0:4); y=x.*exp(-x.*x);s2=spapi(3,x,y)
fnplt(s2,'-',1),hold on;
s1=spapi(2,x,y)
fnplt(s1,' +',2)


fnplt(fnder(spapi(3,x,y)),'-',2),hold on;
fnplt(fnder(spapi(3,x,y),2),'+')
