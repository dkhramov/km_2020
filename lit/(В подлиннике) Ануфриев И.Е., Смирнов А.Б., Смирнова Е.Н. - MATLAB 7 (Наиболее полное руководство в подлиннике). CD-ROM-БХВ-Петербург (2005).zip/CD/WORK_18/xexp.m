function y=xexp(x)
y=x.*exp(-x);
