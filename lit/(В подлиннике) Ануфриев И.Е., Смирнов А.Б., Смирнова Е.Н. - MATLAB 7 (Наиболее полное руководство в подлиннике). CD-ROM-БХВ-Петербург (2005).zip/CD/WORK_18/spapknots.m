 x=(0:4);
 knots=[0 0 0 1 2   4 4 4]
 y=x.*exp(-x.*x);s2=spap2(knots,3,x,y)
fnplt(s2,'-',1),hold on;
%s1=spapi(2,x,y)
%fnplt(s1,' +',2)
