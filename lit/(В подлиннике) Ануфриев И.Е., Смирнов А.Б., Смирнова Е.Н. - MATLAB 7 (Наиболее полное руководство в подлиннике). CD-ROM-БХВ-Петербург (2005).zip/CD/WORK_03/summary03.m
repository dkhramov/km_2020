 x = 0:0.01:1;
 y = exp(-x).*sin(10*x);
%%
%��������� � �����������
 data = [1.2 1.7 2.2 2.4 2.5 1.3 1.1 0.5 0.4 0.1];
 bar(data)
%%
 time = [0.0 0.1 0.2 0.4 0.5 0.8 1.1 1.3];
 data = [2.85 2.93 2.99 3.26 3.01 2.25 2.09 1.79];
 bar(time, data)
%%
 t=-1:0.1:1;
 x=sin(t).*exp(t);
 bar(t,x,1.0)
%%
 data = [19.5 13.4 42.6 7.9];
 pie(data)
%%
 data = [19.5 13.4 42.6 7.9];
 parts = [0 1 0 0];
 pie(data, parts)
%%
 parts = zeros(size(data));
 [mx, ind] = max(data);
 parts(ind) = 1;
 pie(data, parts)
%%
 data = [24.1 10.2 17.4 11.9];
 parts = [1 0 0 0];
 pie3(data, parts)
%%
 data = randn(100000, 1);
 hist(data)
%%
 data = [0.9 1.0 1.1 1.2 1.4 2.4 3.0 3.3];
 centers = [1.1 2.3 3.2];
 hist(data, centers)
%%
  data = [0.9 1.0 1.1 1.2 1.4 2.4 3.0 3.3];
  intervals = [1.1 2.0 3.2];
  count = histc(data, intervals)
  bar(intervals, count)
%%
 data = randn(10000, 1);
 count = hist(data, 5)
%%
 [count, intervals] = hist(data, 5)
%%
 data = load('winddir.dat');
 datarad = data * pi/180;
 rose(datarad)
%������������� ��������� ������
%%
 DATA = [1.2 1.4 1.1
     3.7 3.5 3.1
     2.0 2.8 2.2
     4.2 4.7 4.1];
 bar(DATA)
%%
 bar(DATA,'stack').
%%
 GAIN = [12.0 23.0 48.0
     10.6 31.5 49.0
     8.0 25.0 78.0
     9.6 29.0 61.5];
 area(GAIN)
%%
%������� �������
  x=0:0.05:1;
  y = exp(-x).*sin(10*x);
  plot(x, y)
%%
 x = -2*pi:0.01:2*pi;
 f = exp(-0.1*x).*sin(x).^2;
 g = exp(-0.2*x).*sin(x).^2;
 plot(x, f, x, g)
%%
 x1 = -pi:0.01:2*pi;
 f = exp(-0.1*x1).*sin(x1).^2;
 x2 = -2*pi:0.01:pi;
 g = exp(-0.2*x2).*sin(x2).^2;
 plot(x1, f, x2 ,g)
%%
 x = 0.5:0.01:3;
 f = x.^-3;
 F = 1000*(x+0.5).^-4;
 plotyy(x, f ,x, F)
%%
 x = 0.1:0.01:10;
 f = log(0.5*x);
 g = sin(log(x));
 semilogx(x, f, x ,g)
%%
 x=-1:0.01:1;
 y=sin(2*pi*x.^2);
 xm=-1:0.2:1;
 ym=sin(2*pi*xm.^2);
 plot(x,y,'k',xm,ym,'ko')
%%
 time = [0 4 7 9 10 11 12 13 13.5 14 14.5 15 16 17 18 20 22];
 temp1 = [14 15 14 16 18 17 20 22 24 28 25 20 16 13 13 14 13];
 temp2 = [12 13 13 14 16 18 20 20 23 25 25 20 16 12 12 11 10];
 plot(time, temp1, 'ro-', time, temp2, 'go-')
 grid on
 title('�������� �����������')
 xlabel('����� (���.)')
 ylabel('����������� (C)')
 legend('10 ���', '11 ���')
%%
 t = 0:0.01:2*pi;
 x = 0.5*sin(t);
 y = 0.7*cos(t);
 plot(x, y)
%%
 x1 = -2*pi:pi/100:-pi;
 y1 = pi*sin(x1);
 x2 = -pi: pi/100:pi;
 y2 = pi-abs(x2);
 x3 = pi: pi/100:2*pi;
 y3 = pi*sin(x1).^3;
 x = [x1 x2 x3];
 y = [y1 y2 y3];
 plot(x, y)
%%
 plot(x1, y1,'r*', x2, y2,'g+', x3, y3,'ko')
%%
 [X, Y] = meshgrid(-1:0.05:1, 0:0.05:1);
 Z = 4*sin(2*pi*X).*cos(1.5*pi*Y).*(1-X.^2).*Y.*(1-Y);
%%
 mesh(X,Y,Z)
%%
 surf(X,Y,Z)
%%
 surf(X,Y,Z)
 colorbar
%%
 surfc(X,Y,Z)
 colorbar
%%
 levels=[0:0.01:0.5];
 contour3(X,Y,Z,levels)
 colorbar
%%
  contour(X,Y,Z)
%%
 [CMatr, h] = contour(X, Y, Z);
 clabel(CMatr, h)
 grid on
%%
 contourf(X, Y, Z, 20)
 colorbar
%%
 surfc(X, Y, Z)
 colorbar
 colormap(gray)
 title('������ ������� z(x,y)')
 xlabel('x')
 ylabel('y')
 zlabel('z')
%%
 title('4 sin(2\pi{\itx}) cos(1.5\pi{\ity}) (1-{\ity}^{2})...
{\ity} (1-{\ity})')
%%
 [X, Y] = meshgrid(0:0.05:1, -2:0.05:0);
 Z = -exp(-Y.^2).*cos(3*pi*X).*X.*(1-X).*Y;
 surfc(X, Y, Z)
 colormap(gray)
 colorbar
 title('������ {\itz} = � {\ite}^{-{\ity}^{2}} cos(3 \pi {\itx})... {\itx} (1-{\itx}) {\ity}')
 xlabel('x')
 ylabel('y')
 zlabel('z')
%%
 [Az, El] = view
%%
 t = 0:0.1:100;
 x = exp(abs(t-50)/50).*sin(t);
 y = exp(abs(t-50)/50).*cos(t);
 z = t;
 plot3(x,y,z)
 grid on
%%
 u = (-2*pi:0.1*pi:2*pi)';
 v = [-2*pi:0.1*pi:2*pi];
%%
 X = 0.3*u*cos(v);
 Y = 0.3*u*sin(v);
%%
 Z = 0.6*u*ones(size(v));
%%
 surf(X, Y, Z)
 colorbar
 xlabel('\itx=0.3 \itu cos \itv')
 ylabel('\ity=0.3 \itu sin \itv')
 zlabel('\itz=0.6 \itu ')
%%
 u = (-pi:0.1*pi:pi)';
 v = -pi:0.1*pi:pi;
 X = cos(u)*cos(v);
 Y = 0.9*cos(u)*sin(v);
 Z = 0.8*sin(u)*ones(size(v));
 mesh(X, Y, Z)
 hidden off
%%
 [X, Y] = meshgrid(-1:0.05:1, 0:0.05:1);
 Z = 4*sin(2*pi*X).*cos(1.5*pi*Y).*(1-X.^2).*Y.*(1-Y);
 surfl(X, Y, Z)
 colormap('copper')
 shading interp
 xlabel('x')
 ylabel('y')
 zlabel('z')
%%
 [Az, El] = view;
 surfl(X, Y, Z, [Az-90, 0])
 shading interp
%%
 t = [0:0.001:10];
 x = sin(t)./(t+1);
 y = cos(t)./(t+1);
 comet(x, y)
%%
 t = 0:0.1:100;
 x = exp(abs(t-50)/50).*sin(t);
 y = exp(abs(t-50)/50).*cos(t);
 z = t;
 comet3(x, y, z)
%%
%������ � ����������� ���������
 [X, Y] = meshgrid(-1:0.05:1, 0:0.05:1);
 Z = 4*sin(2*pi*X).*cos(1.5*pi*Y).*(1-X.^2).*Y.*(1-Y);
 figure
 mesh(X, Y, Z)
 figure
 surfl(X, Y, Z)
%%
 colormap('copper')
 shading interp
%%
 sinGr = figure;
 lnGr = figure;
 x = [0.1:0.05:10];
 f = sin(x);
 g = log(x);
 figure(sinGr)
 plot(x, f)
 figure(lnGr)
 plot(x, g)
 figure(sinGr)
 title('\itf=sin\itx')
 figure(lnGr)
 title('\itg=ln\itx')
 grid on
%%
 u = (-2*pi:0.1*pi:2*pi)';
 v = -2*pi:0.1*pi:2*pi;
 X = 0.3*u*cos(v);
 Y = 0.3*u*sin(v);
 Z = 0.6*u*ones(size(v));
 surf(X, Y, Z)
 [X, Y] = meshgrid(-2:0.1:2);
 Z = 0.5*X+0.4*Y;
 hold on
 mesh(X, Y, Z)
 hidden off
%%
 plot(x, f, x, g)
%%
 plot(x, f)
 hold on
 plot(x, g)
%%
 subplot(3,2,1)
 subplot(3,2,2)
 subplot(3,2,3)
 subplot(3,2,4)
 subplot(3,2,5)
 subplot(3,2,6)
%%
 [X, Y] = meshgrid(-1:0.05:1, 0:0.05:1);
 Z = 4*sin(2*pi*X).*cos(1.5*pi*Y).*(1-X.^2).*Y.*(1-Y);
 subplot(3, 2, 1)
 mesh(X, Y, Z)
 title('mesh')
 subplot(3, 2, 2)
 surf(X, Y, Z)
 title('surf')
 subplot(3, 2, 3)
 meshc(X, Y, Z)
 title('meshc')
 subplot(3, 2, 4)
 surfc(X, Y, Z)
 title('surfc')
 subplot(3, 2, 5)
 contour3(X, Y, Z)
 title('contour3')
 subplot(3, 2, 6)
 surfl(X, Y, Z)
 shading interp
 title('surfl')
 colormap(gray)
%%
%������������ ��������� �����
 t=0:0.2:2; 
 x=0.5*t;
 y=0.8*t.*(1-0.5*t);
 ux(1:length(x))=0.5;
 uy=0.8*(1-t);
%%
 quiver(x, y, ux, uy, 0.5)
%%
 quiver(x,y,ux,uy,0)
%%
 quiver(x,y,ux,uy,1.5)
 quiver(x,y,ux,uy,0.3)
%%
 quiver(x,y,ux,uy,'or--')
 quiver(x,y,ux,uy,2.1,'*k:')
%%
 compass(ux,uy)
 feather(ux,uy)
%%
 u = (-pi:pi/15:pi)';
 v = -pi:pi/15:pi;
 X = sin(u)*cos(v);
 Y = sin(u)*sin(v);
 Z=cos(u)*ones(size(v));
 surf(X,Y,Z)
 [U,V,W] = surfnorm(X,Y,Z);
 hold on
 quiver3(X,Y,Z,U,V,W,4,'k');

