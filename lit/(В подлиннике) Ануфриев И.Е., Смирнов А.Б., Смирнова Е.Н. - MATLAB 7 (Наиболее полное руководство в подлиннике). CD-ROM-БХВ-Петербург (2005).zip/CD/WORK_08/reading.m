F = fopen('student1.txt', 'r');
Family = fscanf(F, '%s', 1)
Year = fscanf(F, '%d', 1)
Status = fscanf(F, '%s', 1)
Group = fscanf(F, '%s', 1)
MeanMark = fscanf(F, '%g', 1)
fclose(F);
