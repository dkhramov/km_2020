function pos = strnumpos1(str)
slen = length(str);
digits = 0;
pos =[];
for k = 1:slen
   a = str2num(str(k)); 
   if length(a)~= 0
      digits = digits + 1;
      pos(digits) = k;
   end
end
