Len = length(GR201);
for k = 1:Len
   disp(GR201(k))
end
