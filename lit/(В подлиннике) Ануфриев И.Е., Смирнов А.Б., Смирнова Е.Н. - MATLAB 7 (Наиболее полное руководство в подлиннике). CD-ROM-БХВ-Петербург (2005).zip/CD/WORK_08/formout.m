[F, mes] = fopen('twonum.txt', 'w');
x = -pi/4;
y = sin(x);
fprintf(F, '%7.4f%11.8f', x, y);
fclose(F);
myview('twonum.txt');
