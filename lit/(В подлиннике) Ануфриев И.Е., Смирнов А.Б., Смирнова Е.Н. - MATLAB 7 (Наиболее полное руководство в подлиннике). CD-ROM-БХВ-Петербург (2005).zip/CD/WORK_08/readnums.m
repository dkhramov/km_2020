F = fopen('res.dat', 'r');
vect = fscanf(F, '%g')
fclose(F);
