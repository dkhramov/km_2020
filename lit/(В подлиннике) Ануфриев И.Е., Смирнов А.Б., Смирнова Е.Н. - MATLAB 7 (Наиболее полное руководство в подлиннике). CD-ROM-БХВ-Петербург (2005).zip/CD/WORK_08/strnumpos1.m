function pos = strnumpos1(str)
slen = length(str);
digits = 0;
pos = [];
for k = 1:slen
   if isnumeric(str(k))
      digits = digits + 1;
      pos(digits) = k;
   end
end
