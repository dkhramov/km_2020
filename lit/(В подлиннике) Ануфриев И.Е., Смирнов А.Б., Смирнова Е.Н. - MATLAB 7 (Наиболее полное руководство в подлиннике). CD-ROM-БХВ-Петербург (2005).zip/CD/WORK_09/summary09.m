x=0:0.1:10;
y=sin(x);
plot(x,y)
%%
get(gca)
%%
fn=get(gca,'FontName')
%%
set(gca,'LineWidth',2)
set(gca,'YTick',[-1 0 1])
set(gca,'YTickLabel',{'y=-1';'y=0';'y=1'})
set(gca,'XGrid','on')
set(gca,'GridLines','-')
set(gca,'Color',[0.8 0.8 0.8])
%%
set(gco,'Color','k')
set(gco,'LineWidth',2)
set(gco,'Marker','o')
set(gco,'MarkerFaceColor','w')
set(gco,'MarkerSize',8)
%%
delete(hLines(1))
%%
axes(hAx)
cla
%%
plot(t,x,t,y,'Color','r','LineWidth',3,'Marker','o')
%%
hF=figure('Color','w','MenuBar','none')
%%
p1=get(hF,'Position')
%%
p2=get(hF,'Position')
%%
s=get(0,'ScreenSize')
%%
hF=figure('MenuBar','none','Color','w');
hAx=axes('Box','on');
a=get(hAx,'Position')
%%
hA=axes('Position',[0.2 0.2 0.6 0.6])
%%
t=get(hA,'TightInset')
%%
ylabel('��� y')
t=get(hA,'TightInset')
%%
hFigs = fig2;
hAxTop = axes3(hFigs(1));
hAxBot = axes3(hFigs(2));
%%
zeroandmin(@sin, -pi, pi)
%%
hTxt = title('������ ������� sin({\itx})')
%%
set(hTxt, 'Color', 'r')
%%
zeroandmin_new(@sin, -pi, pi)
%%
figure
hTA=annotation('textarrow',[0.5 0],[0.5 0]);
%%
txt{1}='������ ���������';
txt{2}='������������ ����'
set(hTA, 'String',txt)
%%
set(hTA,'HeadStyle','plain')
%%
set(hTA,'Color','m')
%%
set(hTA,'TextEdgeColor','b')
%%
set(hTA,'TextColor','g')
%%
hR=annotation('rectangle',[0.3 0.2 0.5 0.6],'EdgeColor','r',...
'FaceColor','g')
%%
new_zeroandmin(@sin, -pi, pi)
%%
get(0,'DefaultFigureColor')
%%
set(0,'DefaultFigureColor','w')
%%
figure
%%
figure('Color','k')
%%
hF=figure('MenuBar','none','NumberTitle','off',...
'Name','���������� ������');
%%
hF=figure;
hA=axes('DataAspectRatio',[1 1 1],'XLim',[0 1],'YLim',[0 1]);
hR=rectangle('Position',[0.25 0.25 0.5 0.5],'Curvature',[1 1]);
%%
hA=axes('Position',[0 0 1 1],'XLim',[0 100],'YLim',[0 100],...
'DataAspectRatio',[1 1 1],'Visible','off'); 
%%
hP=patch(rand(4,3),rand(4,3),'r')
%%
figure
colormap(gray)
%%
x=[0; 1; 2; 3];
y=[0; 2; 2; 0];
C=[1; 1; 0; 0];
%%
patch(x,y,C)
%%
figure
C(1,1,1:3)=[1 0 0];
C(2,1,1:3)=[0 1 0];
C(3,1,1:3)=[0 0 1];
C(4,1,1:3)=[0 0 0];
patch(x,y,C)    
%%
 hF=figure;
hA=axes('CameraPosition',[10 12 8]);
V=[-1  0 0
       0  1 0
       1  0 0
       0 -1 0
       0  0 2];
F=[1 2 3 4 
      5 4 1 NaN
      2 1 5 NaN
      3 2 5 NaN
      4 3 5 NaN]; 
hP=patch('Vertices',V,'Faces',F,'FaceColor','w')
%%
FC=[0 0 0
        0 1 0
        0 0 1
        1 0 0
        1 1 0]
hP=patch('Vertices',V,'Faces',F,'FaceColor','flat',...
'FaceVertexCData',FC)
%%
set(hP,'FaceAlpha',0.5)
%%
T=[1; 1; 1; 1; 0]
set(hP,'FaceVertexAlphaData',T,'FaceAlpha','interp')
set(hP,'LineWidth',3,'EdgeColor','c','EdgeAlpha','interp')
%%
u = (-pi:0.05*pi:pi)';
v = -pi:0.05*pi:pi;
X = 0.3*u*cos(v);
Y = 0.3*u*sin(v);
Z = 0.6*u*ones(size(v));
hF=figure;
hA=axes;
%%
hS=surface('XData',X,'YData',Y,'ZData',Z,'FaceColor','g',...
'LineStyle','none')
%%
set(hA,'CameraPosition',[-15 -25 20])
%%
hLt=light('Position',[0 -1 0])
%%
set(hA,'CameraPosition',[0 1 0])          
%%
set(hA,'AmbientLightColor','k')
%%
set(hA,'CameraPosition',[-15 -25 20])             
set(hA,'AmbientLightColor','w')
%%
set(hS,'FaceLighting','gouraud')
%%
set(hS,'LineStyle','-')
set(hS,'EdgeColor','g')
set(hS,'EdgeLighting','phong')
%%
set(hS,'BackFaceLighting','unlit')
%%
material metal
material shiny
material dull
material default
%%
set(hLt,'Style','local') 
%%
hF=figure;
hA=axes;
hB=bar([1 2 3 1]);
hF1=figure;
%%
set(hA,'Parent',hF1)
%%
hA=axes;
hC1=get(hA,'Children')
%%
hC=allchild(hA)
%%
get(hC(1),'Visible')
%%
get(hC,'Type')
%%
set(hC(1),'String','���������')
hT=get(hA,'Title');
set(hT,'String','���������')
%%
get(hC,'HandleVisibility')
%%
set(0,'ShowHiddenHandles','on')
%%
hC1=get(hA,'Children')
%%
set(0,'ShowHiddenHandles','off')
%%
hF=figure('HandleVisibility','off')
%%
fplot(@sin,[0 3*pi])
%%
set(1,'Color','w')
%%
hC=findall(hF)
%%
hC=findall(hF,'Type','patch','FaceColor','k')
set(hC,'FaceColor',[0.8 0.8 0.8])
%%
hF=figure;
hA=axes('CameraPosition',[10 12 5]);
[X,Y]=meshgrid(-2:0.5:2);
Z=zeros(size(X)).*zeros(size(Y));
hS=surface('XData',X,'YData',Y,'ZData',Z,'FaceColor','y',...
    'EdgeColor','r','FaceAlpha',0.8,'EdgeAlpha',0.8);
V=[-1  0 0
       0  1 0
       1  0 0
       0 -1 0
       0  0 1];
F=[1 2 3 4 
      5 4 1 NaN
      2 1 5 NaN
      3 2 5 NaN
      4 3 5 NaN]; 
hP=patch('Vertices',V,'Faces',F,'FaceColor','g','EdgeColor','r',...
    'FaceAlpha',0.8,'EdgeAlpha',0.8);
%%
hGT=hgtransform('Parent',hA);
%%
set(hS,'Parent',hGT)
set(hP,'Parent',hGT)
%%
hGT0=copyobj(hGT,hA);
hC0=get(hGT0,'Children')
set(hC0,'FaceAlpha',0.1,'EdgeAlpha',0.1)
%%
Tz = makehgtform('translate',[0 0 2])
%%
set(hGT,'Matrix',Tz)
%%
Ty = makehgtform('translate',[0 1 0]);
set(hGT,'Matrix',Ty)
%%
T=Ty*Tz
set(hGT,'Matrix',T)
%%
Tx1=makehgtform('translate',[2 0 0])
Ry=makehgtform('yrotate',pi/2)
Tx2=makehgtform('translate',[-2 0 0])
T=Tx2*Ry*Tx1
set(hGT,'Matrix',T)
%%
T2=Tx1*Ry*Tx2
set(hGT,'Matrix',T)
%%
T3=Tx1*Tx2*Ry
set(hGT,'Matrix',T3)
%%
T=eye(4)
set(hGT,'Matrix',T)
%%
x=0:0.1:10;
f=sin(x);
g=cos(x);
hF=figure
hA=axes
hL=plot(x,f,x,g)
set(hL(1),'DisplayName','sin {\itx}')
set(hL(2),'DisplayName','cos {\itx}')
%%
hLG=legend(hA,'show')
%%
set(hL(2),'DisplayName','������ ��������')
%%
legend(hLG)
%%
time=0:0.05:8;
fun=sin(time).^2;
hF=figure;
hA=axes;
hL=plot(time,fun);
set(hL,'XDataSource','time','YDataSource','fun');
fun=sin(time).^3;
refreshdata(hL)
%%
[X,Y]=meshgrid(-1:0.2:1,-2:0.2:0);
Z=sin(pi*X.*Y).*(X+Y);
[C,hC]=contour(X,Y,Z)
%%
[X,Y]=meshgrid(-1:0.01:1,-2:0.01:0);
Z=sin(pi*X.*Y).*(X+Y);
set(hC,'XData',X,'YData',Y,'ZData',Z)
%%
LS=get(hC,'LevelStep')
set(hC,'LevelStep',LS*2)
LL=get(hC,'LevelList')
LL=[LL -0.6 -1.7] 
set(hC,'LevelList',LL)     
%%
hT=findobj(hC,'Type','Text')
set(hT,'BackgroundColor','g','EdgeColor','r')



