load set19.mat
%%
>> cftool
