format short g
now_date= '07-jul-2004';
Km = 96
Ka =96.5
Kb = 95.5
[yldbid, discbid, profbid] = profit_zero(now_date, Kb) 
[yldask, discask, profask] = profit_zero(now_date, Ka) 
[yldm, discm, profm] = profit_zero(now_date, Km)
