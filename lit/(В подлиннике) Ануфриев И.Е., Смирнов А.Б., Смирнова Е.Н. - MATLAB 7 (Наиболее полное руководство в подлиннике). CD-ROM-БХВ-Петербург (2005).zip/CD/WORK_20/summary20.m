 format long g
 mom = now
%%
  date1 = datenum(2004, 21, 05)
%%
 date2 = datestr(date1,1)
%%
 date1 = datenum('21/05/2004')
%%
date1 = datenum('05/21/2004');
date2 = datenum('01/13/2003');
n_fact = daysdif (date1, date2, 0)
n_365 = daysdif (date1, date2, 3)
n_360 = daysdif (date1, date2, 1)
%%
rest_days = datestr(holidays('01-Jan-2004 ', '03-May-2004 '))
%%
cf11 = [ 0 0 0 47 0 53 0 30 0 20];
dur1 = cfdur(cf11,0.1/2)
cx1 = cfconv(cf11,0.1/2)
%%
cf21 =[ 0 25 0 15 0 0 0 30 40 40];
dur2 = cfdur(cf21,0.1/2)
cx2 = cfconv(cf21,0.1/2)
%%
[SC, SI, B, Payment] = amortize(0.2, 3, 150, -4.4)
%%
 annurate(3, 70, 150 )
%%
 payper(0.2, 3, 150)
%%
annuterm(0.1, 50, 0, 150 )%%
%%
 fvfix(0.1/4, 3*4, 15)
%%
 d0= discrate('10-dec-2003',  '10-oct-2004',100000, 87000, 0) 
%%
zero_test 
%%
 next = datestr(cpndaten('15-may-2004', '30-nov-2004', 4))
%%
 [price, accrue] = bndprice(0.09, c, C_Date, M_Date, m, b,�
m_end,[], [], [], [], S)
%%
 Yield = bndyield(975, c, C_Date, M_Date, m, b, m_end,[],[],[],[],S)
%%
[ModDur, YearDur, PerDur] = bnddury(0.09, c, C_Date, M_Date, m, b, m_end,[], [], [], [], S )
%%
 P_Ret =[0.12 0.14 0.16 0.18];
 [P_Risk, P_Ret, P_Ass] = portopt(A_yld, A_cov, [], P_Ret)
%%
 [P_Risk, P_Ret, P_Ass] = portopt(A _yld, A _cov, 4)
%%
 Restr_Set = portcons('PortValue', 1.25,3,'Default', 3)
