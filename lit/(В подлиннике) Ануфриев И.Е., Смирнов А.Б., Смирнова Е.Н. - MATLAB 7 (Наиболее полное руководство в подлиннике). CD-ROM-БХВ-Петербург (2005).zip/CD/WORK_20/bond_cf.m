I_Date= '01-dec-2003';
C_Date= '15-may-2004';
M_Date= '30-nov-2004';
b=0;
m=4;
c = 0.08;
S =1000;
m_end = 1; 
[paym, CFDates, d_fact, flags] =cfamounts(c, C_Date, M_Date,m,� 
b, m_end,[], [], [], [], S);
Dates_1 =datestr(CFDates, 1)
fprintf('\n payment \n');
fprintf('%12.3f ',paym);
fprintf('\n d_factors \n');
fprintf(' %10.5f',d_fact);
fprintf('\n flags \n');
fprintf(' %6.2f',flags);
