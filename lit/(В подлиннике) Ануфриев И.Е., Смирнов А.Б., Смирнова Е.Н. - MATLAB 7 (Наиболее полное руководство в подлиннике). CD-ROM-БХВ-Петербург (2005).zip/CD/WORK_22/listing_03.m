function varargout = myplot(varargin)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @myplot_OpeningFcn, ...
                   'gui_OutputFcn',  @myplot_OutputFcn, ...
                   'gui_LayoutFcn',  [], ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
   gui_State.gui_Callback = str2func(varargin{1});
end
if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

function myplot_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
guidata(hObject, handles);

function varargout = myplot_OutputFcn(hObject, eventdata, handles)
varargout{1} = handles.output;

function FunEdt_Callback(hObject, eventdata, handles)
myplotprog('SetFun')

function PlotBtn_Callback(hObject, eventdata, handles)
myplotprog('PressPlot')

function ClearBtn_Callback(hObject, eventdata, handles)
myplotprog('PressClear')
