myplot
%%
set(0,'ShowHiddenHandles','on')
%%
 h = get(0,'Children')
%%
 guide(h)
%%
 open('myplot.fig')
