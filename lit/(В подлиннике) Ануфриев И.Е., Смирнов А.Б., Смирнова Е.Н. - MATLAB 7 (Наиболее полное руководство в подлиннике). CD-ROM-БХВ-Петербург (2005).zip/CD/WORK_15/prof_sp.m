n=3000; % dimension of matrix
e=ones(n,1); % define unit column
% compose three-diagonal matrix in compact form
SN = spdiags([-e 3*e -e],-1:1,n,n);
% change two elements in matrix by 1 
SN(1,n)=1;
SN(n,1)=1;
% factorization sparse matrix
RN = chol(SN);
