A = [5  0 -3  0  0  0
       0 -2  0  0  2  0
       0  0  1  0  0  0
       0  0  0  0  0  0
       9  7  0  0  0  0];
%%
AN = sparse(A)
%%
whos A AN
%%
Af = full(AN)
%%
 irow = [1 5 2 5 1 3 2];
 jcol = [1 1 2 2 3 3 5];
nzer = [5 9 -2 7 -3 1 2];
 AN=sparse(irow, jcol, nzer, 5, 6)
%%
irow = [1 1 2 2 3 5 5];
jcol = [1 3 2 5 3 1 2];
nzer = [5 -3 -2 2 1 9 7];
AN=sparse(irow, jcol, nzer, 5, 6);
%%
irow = [1 1 2 2 3 5 5];
jcol = [1 3 2 5 3 1 2];
nzer = [5 -3 -2 2 1 9 7];
AN=sparse(irow, jcol, nzer, 5, 6);
%%
 irow = [1 2 3 2 1 5 5 5];
jcol = [3 2 3 5 1 2 1 1];
nzer = [-3 -2 1 2 5 7 9 10];
AN=sparse(irow, jcol, nzer, 5, 6);
full(AN)
%%
irow = [1 5 2 4 3 4 5 1 3 2];
jcol = [1 1 2 5 2 6 2 3 3 5];
nzer = [5 9 -2 0 0 0 7 -3 1 2];
AN=sparse(irow, jcol, nzer, 5, 6);
[ir,jr,nz]=find(AN)
%%
 irow = [1 1];
 jcol = [1 2];
 nzer = [2 3];
SN=sparse(irow, jcol, nzer)
full(SN)
%%
 irow = [1 1 2];
jcol = [1 2 2];
nzer = [2 3 0];
SN=sparse(irow, jcol, nzer);
full(SN)
%%
s = load('spmatr.dat');
A = spconvert(s);
%%
B = [1     5     0
        1     3     0
        1     7    -3
        1    22    -1
        0     8    -2];
%%
d =[-1 0 2];
%%
A = spdiags(B, d, 5, 5);
%%
[B,d] = spdiags(A)
%%
AN(5,1)
AN(4,3)
%%
CAN=cos(AN);
whos CAN
%%
ca = full(CAN);
 whos ca
%%
gn = sparse(A)
max(gn)
min(gn)
%%
 irow=[1 1 1 2 2 2 3 3 4 4 5 5 5 6 6 6];
jcol=[1 2 5 1 2 3 2 3 4 6 1 5 6 4 5 6];
 nzer=[4 1 1 1 4 1 1 4 4 1 1 4 1 1 1 4];
 BN=sparse(irow,jcol,nzer,6,6)
%%
R =  chol(BN);
%%
rind = symrcm(BN)
%%
full(BN(rind,rind))
%%
R = chol(BN(rind,rind));
spy(R)
%%
 profile on -detail builtin
prof_sp
 profile off
%%
profile viewer
%%
stat_data= profile('info')
profsave(stat_data,'html_report')
