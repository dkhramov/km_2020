if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end  
