profile on -detail builtin
AS=sym(hilb(15));
vs=eig(AS)
A=hilb(15);
v=eig(A)
profile report
