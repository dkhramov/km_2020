function F = rikkaty(x, y)
F = [1/x^2-y(1)^2];
