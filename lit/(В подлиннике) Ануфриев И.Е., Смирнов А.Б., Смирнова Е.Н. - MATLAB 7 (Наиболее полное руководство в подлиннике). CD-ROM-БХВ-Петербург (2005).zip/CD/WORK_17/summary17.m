syms x a b
%%
whos x a b
%%
f=(sin(x)+a)^2*(cos(x)+b)^2/sqrt(abs(a+b))
%%
pretty(f)
%%
syms y
g = (exp(-y)+1)/exp(y)
h=f*g
pretty(h)
%%
z = sym('c^2/(d+1)')
%%
pretty(z)
%%
syms a b real
p=conj(a+i*b)
%%
syms a b unreal
q=conj(a+i*b)
%%
syms a b c d e f g h
A=[a b; c d]
B=[e, f; g, h]
C=A*B
%%
F=A.*B
%%
D=[C A; B C]
%%
d2=D(2,:)
%%
d=d2([1 3 4])
%%
D(1:2,:)=[]
%%
A = [1.3 -2.1 4.9
       6.9  3.7 8.5];
B = sym(A)
%%
c=[3.2; 0.4; -2.1];
%%
d=sym(c);
%%
e=B*d
%%
format long e
1.0e+10+1.0e-10
%%
large = sym(1.0e10);
small = sym(1.0e-10);
s = large+small
%%
c=sym('sqrt(2)');
cn=vpa(c)
%%
cn=vpa(c,70)
%%
whos cn
%%
cnum=double(cn)
%%
f=sym('x^2*sin(x)');
ezplot(f)
%%
ezplot(f,[-3 2])
%%
z=sym('x^2+y^3');
ezplot(z,[-2 1 -3 4])
%%
ezsurf('asin(x^y)', [0 6 -7 7])
%%
p=sym('(x+a)^4+(x-1)^3-(x-a)^2-a*x+x-3');
pretty(p)
%%
pc=collect(p);
pretty(pc)
%%
pca=collect(p, 'a');
pretty(pca)
%%
pe=expand(p);
pretty(pe)
%%
f=sym('sin(arccos(3*x))+exp(2*log(x))');
 fe=expand(f);
 pretty(fe)
%%
p=sym('x^5+13*x^4+215/4*x^3+275/4*x^2-27/2*x-18');
pf=factor(p);
pretty(pf)
%%
syms a
a=sym('230010');
s=factor(a)
%%
s1=factor(230010)
%%
f=sym('(a^2+b^2)/(a^2-b^2)+a^4/b^4');
f=subs(f,'a','(exp(x)+exp(-x))');
f=subs(f,'b','(sin(x)+cos(x))');
pretty(f)
%%
f=sym('(a^2+b^2)/(a^2-b^2)+a^4/b^4');
f=subs(f,{'a','b'},{'(exp(x)+exp(-x))', '(sin(x)+cos(x))'});
 pretty(f)
%%
f=sym('exp(x^3+2*x^2+x+5)');
q=subs(f,'x',1.1)
%%
q=subs(f,'x','1.1')
%%
vpa(q,50)
%%
A=sym('[a b c; d e f; g h j]');
D=det(A)
%%
AI=inv(A);
pretty(AI)
%%
pA=poly(A);
pretty(pA)
%%
f=sym('1/(1+x)');
tf=taylor(f);
pretty(tf)
%%
syms y
g=sym('1/(x+y)');
tg=taylor(g,7,y);
pretty(tg)
%%
pretty(taylor('exp(x)',4,x,1/2))
%%
syms k
s = symsum('(-1)^k/k^2',k,1,Inf)
%%
syms k x
s = symsum((-1)^(k)*x^(2*k+1)/sym('(2*k+1)!'),k,0,Inf)
%%
syms a x
limit((1+1/x)^(x*a),x,Inf)
%%
syms b x
 limit((10+x)^(1/x),x,0,'left')
 limit((10+x)^(1/x),x,0,'right')
 %%
limit((10+x)^(1/x),x,0)
%%
syms h x
L=limit((atan(x+h)-atan(x))/h,h,0);
pretty(L)
%%
P=diff('atan(x)',x,1);
pretty(P)
%%
tangent('sin(x)*x^2',2)
%%
syms x
 f=sym('x^3*exp(x)');
 I=int(f,x)
 pretty(I)
 %%
diff(I,x,1)
%%
syms x
 f=sym('exp(sin(x)^2)*cos(x)');
 I=int(f,x);
 pretty(I)
%%
syms x a b
 f=sym('(x^3+1)/(x-1)');
I=int(f,x,a,b);
 pretty(I)
%%
syms a b c d x y
 f=sym('y*sin(x)');
 Ix=int(f,x,a,b)
%%
Iy=int(Ix,y,c,d)
pretty(Iy)
%%
syms x
 f=sym('x^3-x^2-5*x+1');
 r=solve(f,x);
 pretty(r)
%%
simplify(subs(f,'x',r(1)))
%%
syms x
 f=sym('a*x^4+b*x^3+c*x^2+d*x+c');
 pretty(solve(f,x))
%%
syms x1 x2
 f1=sym('a*x1^2+x1*x2+1');
 f2=sym('x1^2+b*x2');
 s=solve(f1,f2,x1,x2);
 r1=subs(f1,{x1,x2},{s.x1(1), s.x2(1)})
 simplify(r1)
 r2=subs(f2,{x1,x2},{s.x1(1), s.x2(1)})
 r1=subs(f1,{x1,x2},{s.x1(2), s.x2(2)})
 simplify(r1)
 r2=subs(f2,{x1,x2},{s.x1(2), s.x2(2)})
%%
syms x1 x2
  f1=sym('x1*(2-x2)-cos(x1)*exp(x2)');
  f2=sym('2+x1-x2-cos(x1)-exp(x2)');
  s=solve(f1,f2,x1,x2);
%%
s.x1
s.x2
%%
[x1, x2]=solve(f1,f2,x1,x2);
%%
[x1,x2]=solve('x1*(2-x2)=cos(x1)*exp(x2)','2+x1-x2=cos(x1)+exp(x2)')
%%
y=dsolve('Dy+y^2=x^(-2)', 'y(0.5)=-1','x');
pretty(y)
%%
[X, Y] = ode45('rikkaty', [0.5 7], -1);
%%
ezplot(y)
  hold on
  plot(X,Y,'o')
  grid on
%%
[f,g]=dsolve('Df=exp(-g)', 'Dg=exp(-f)');
%%
pretty(f)
%%
pretty(g)
%%
syms t
  u1=diff(f,t)-exp(-g)
%%
u2=diff(g,t)-exp(-f)
%%
simplify(u2)
%%
  [f,g]=dsolve('Df=exp(-g)', 'Dg=exp(-f)', 'Df(5)=1', 'Dg(5)=3');
%%
  [f,g]=dsolve('Df=exp(-g), Dg=exp(-f)', 'Df(5)=1, Dg(5)=3');
%%
  y=dsolve('(1-x^2)*D2y-2*x*Dy+n*(n-1)*y=0','x')
%%
  mhelp LegendreP
%%
   mfun('LegendreP', 5, 0.7)
