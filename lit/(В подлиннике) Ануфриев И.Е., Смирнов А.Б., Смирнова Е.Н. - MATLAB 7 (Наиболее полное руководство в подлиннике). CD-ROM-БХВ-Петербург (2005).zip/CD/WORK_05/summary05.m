y=[1 2 3]
z=y*y
x=y
%%
 edit mydemo
%%
 edit mydemo4
 %%
 mydem
%%
clear all
%%
cd �:\users\igor
%%
addpath �:\elena 
%%
addpath �:\alex -end
%%
y = myfun(1.3)
%%
x = [1.3 7.2];
y = myfun(x)
%%
 x = 0:0.5:4;
y = myfun(x);
plot(x, y)
%%
fplot('myfun',[0 4]) 
%%
fplot(@myfun,[0 4]) 
%%
fplot(@myfun1,[0 1],'.-')
%%
R = radius3(1, 1, 1)
%%
[H, M, S] = hms(10000)
%%
simple1
%%
mainfun
%%
f = fixed_parm (1.5, 2, 0);
g = fixed_parm(1, 10, 25);
fplot(f, [-2,2])
hold on;
 fplot(g, [-2,2])
