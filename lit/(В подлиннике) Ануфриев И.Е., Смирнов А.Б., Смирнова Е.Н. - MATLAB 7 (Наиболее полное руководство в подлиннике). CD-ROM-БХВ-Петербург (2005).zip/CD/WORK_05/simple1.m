function simple1;
ALP = 5.3;
BET = 9.1;
f1 = f(1.1,2.1)
function z = f(x,y)
z = x^3 - 2*y^3 + 3*(x^2+y^2)- x*y + 9 + ALP*BET;
