function f = myfun(x)
f = exp(-x).*sqrt((x.^2+1)./(x.^4+1));
