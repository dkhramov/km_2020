function z = myfun1(t)
z = exp(-t).*(sin(t)+0.1*sin(100*pi*t));
