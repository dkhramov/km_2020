function r = radius3(x, y, z)
r = sqrt(x.^2 + y.^2 + z.^2);
