x = [0:0.1:7];
f = exp(-x);
subplot(1, 2, 1)
plot(x, f)
g = sin(x);
subplot(1, 2, 2)
plot(x, g)
