function Line_ButtonDownFcn(hObject, eventdata,handles)
Coord=get(handles.axes,'CurrentPoint')
x=Coord(2,1); y=Coord(1,2); 
X=get(handles.Line,'XData')
Y=get(handles.Line,'YData')
X=[X x]
Y=[Y y]
set(handles.Line,'Xdata',X,'Ydata',Y)
