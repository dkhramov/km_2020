P = ones(16);
MP(2:15,2:15) = NaN;
set(gcf, 'Pointer', 'custom')
set(gcf, 'PointerShapeCData', MP)
