function btnPlot_Callback(hObject, eventdata, handles)
x = -2:0.2:2;
y = exp(-x.^2);
plot(x,y)
