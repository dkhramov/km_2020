function btnClear_Callback(hObject, eventdata, handles)
cla
