function F = syst(t,y)
F = [y(2); exp(t).*(sin(t)+2*cos(t))-y(1)];
