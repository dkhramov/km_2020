function B = matrf(A)
B = exp(A).*sin(A);
