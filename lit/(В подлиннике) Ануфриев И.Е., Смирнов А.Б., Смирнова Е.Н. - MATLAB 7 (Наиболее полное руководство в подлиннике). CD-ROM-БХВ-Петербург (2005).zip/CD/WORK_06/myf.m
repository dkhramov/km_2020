function y = myf(x)
y = sin(x)-x.^2.*cos(x);
