function [x, y] = froot(p1, p2, x0)
 [x, y] = fzero(@pfun, x0);
    function f = pfun(x)
    f = exp(p1*x)-p2*sin(x);
    end
end
