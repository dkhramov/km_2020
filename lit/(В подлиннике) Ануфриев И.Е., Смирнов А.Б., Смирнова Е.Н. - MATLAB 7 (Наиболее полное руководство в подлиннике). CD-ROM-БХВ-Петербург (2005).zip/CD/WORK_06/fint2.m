function f = fint2(x, y)
f = exp(x).*sin(y).^2+exp(-x).*cos(y).^2;
