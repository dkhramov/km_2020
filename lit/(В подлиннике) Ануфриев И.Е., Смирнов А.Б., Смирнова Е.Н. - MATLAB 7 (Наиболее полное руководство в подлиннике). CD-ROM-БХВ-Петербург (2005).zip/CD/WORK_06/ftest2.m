function f = ftest2(v)
x = v(1);
y = v(2);
f = sin(pi*x).*sin(pi*y);
