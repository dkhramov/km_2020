function f = pfun(x,p1,p2)
f = exp(p1*x)-p2*sin(x);
