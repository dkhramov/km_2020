function f = fint(x)
f = exp(-x).*sin(x);
