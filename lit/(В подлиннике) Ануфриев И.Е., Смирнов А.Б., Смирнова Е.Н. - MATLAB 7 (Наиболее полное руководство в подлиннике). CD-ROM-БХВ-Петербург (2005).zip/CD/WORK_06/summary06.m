%%
fun = inline('sin(x)-x.^2.*cos(x)')
%%
y=fun(0.5)
%%
fun1 = inline('sin(a*x)-x.^2.*cos(b*x)')
%%
fun2 = inline('sin(a*x)-x.^2.*cos(b*x)', 'x', 'a', 'b'
%%
fun3 = inline('sin(a*x)-x.^2.*cos(b*x)','x', 'b')
%%
a=1;
fun3(5,0)
%%
a= 1;
gun3 = @(x, b) (sin(a*x)-x.^2.*cos(b*x))
%%
gun3(5,0)
%%
a= 1000;
gun3(5,0)
%%
whos gun3
%%
fplot('myf', [-5 5])
grid on
%title(' ������ ������� myf - ������ ����� ���������');
%%
myf(x1)
%%
format long
x1
%%
format long e
 x1
%%
 x1 = -4.756559405702905e+000;
myf(x1)
%%
x4 = fzero('myf', -0.1)
%%
x2 = fzero('myf', [-3 -1])
%%
fzero('sin', [2 4])
%%
x2 = fzero(@myf, [-3 -1]);
%%
fun = inline('sin(x)-x.^2.*cos(x)')
%%
x1 = fzero(fun, -5)
%%
fun = @(x) sin(x)-x.^2.*cos(x)
%%
x1 = fzero(fun, -5)
%%
[x2, f] = fzero(@myf, -2)
%%
fun=inline('x.^2');
%%
x = fzero(fun,-0.1)
%%
[x1,f1,flag] = fzero(fun,0.1);
%%
p = [1 0 3.2 -5.2 0 0.5 1 -3];
%%
polyval(p,1)
%%
r = roots(p)
%%
polyval(p,r)
%%
x2 = fminbnd(@ftest, -0.5, 0)
%%
xx = fminbnd('ftest', -1.5, 1.5)
%%
[x2, f] = fminbnd(@ftest, -0.5, 0)
%%
[x2, f, flag] = fminbnd(@ftest, -0.5, 0);
%%
x2 = fminsearch(@ftest, -0.5)
%%
[X,Y]=meshgrid(0:0.01:2);
Z=sin(pi*X).*sin(pi*Y);
[CMatr, h]=contour(X,Y,Z,[-0.96,-0.9,-0.8,-0.5,-0.1,0.1,0.5,0.8,0.9,0.96]);
clabel(CMatr,h)
colormap(gray)
%%
M = fminsearch('ftest2', [1.4, 0.6])
%%
[M, f] = fminsearch(@ftest2, [1.4, 0.6])
%%
[M, f, flag] = fminsearch(@ftest2, [1.4, 0.6]);
%%
fun= @(v)sin(pi*v(1)).*sin(pi*v(2));
[M, f] = fminsearch(fun, [1.4, 0.6])
%%
format long
options = optimset('Display', 'final');
x2 = fminbnd(@ftest, -0.5, 0, options)
%%
options = optimset('Display', 'final', 'TolX', 1.0e-09);
x2 = fminbnd(@ftest, -0.5, 0, options)
%%
options = optimset('Display', 'iter','TolX', 1.0e-09);
x2 = fminbnd(@ftest, -0.5, 0, options)
%%
options = optimset('TolX',1.0e-09);
%%
options = optimset(options,'TolFun',1.0e-07,'Display','iter');
%%
err = optimget(options,'TolX')
%%
>> fun = inline('sin(1/x)')
subplot(2,1,1)
fplot(fun,[0.01 1])
subplot(2,1,2)
fplot(fun,[0.01 1],1.0e-4)
%%
 fplot(@pfun,[-3 3],[],[],'-',0.1,2);
 hold on
fplot(@pfun,[-3 3],[],[],'--',0.2,2.5);
fplot(@pfun,[-3 3],[],[],':',0.3,3.7);
%%
[x1,f1] = fzero(@pfun,0,[],0.1,2)
%%
p1 = 0.1;
p2 = 2;
[x1,f1] =fzero(@(x) exp(p1*x)-p2*sin(x), 0)
%%
format long
I = quad(@fint, -1, 1)
%%
I = quad(@fint, -1, 1, 1.0e-07)
%%
I = quad(@fint, -1, 1, 1.0e-07, 3)
%%
fun = inline('x.^-0.9');
I = quad(fun,0,1,1e-7)
%%
dblquad(@fint2, -pi, pi, 0, 1)
%%
format long
dblquad(@fint2, -pi, pi, 0, 1, 1.0e-012, 'quadl')
%%
q = quad(@fparam, -1, 1, 1.0e-05, 1, 22.5, -5.9)
%%
Par1 = 22.5; 
Par2 = -5.9;
q = quad(@(x) Par1.*x.^2+Par2.*sin(x), -1, 1, 1.0e-05)
%%
p = [1 0 1 0 0 1];
q = [1 2 3];
s = conv(p, q)
%%
[d, r] = deconv(p, q)
%%
s = polysum(p, q)
%%
d = polysum(p, -q)
%%
p = [1 0 1 0 0 1];
p1 = polyder(p)
%%
p = [1 0 1 0 0 1];
q = [1 2 3];
pq1 = polyder(p, q)
%%
[n, d] = polyder(p, q)
%%
 A = [2 3 3
       4 2 3
       6 5 6];
b = [8; 7; 7];
x = A\b
%%
det(A)
%%
[a,b]=fit
%%
A = [2 3 3
       -2 -3 -3];
 b = [8; 7];
X = linsolve(A,b)
%%
[X,r] = linsolve(A,b)
%%
A = [1 2;  3 4;   5 6];
 P = pinv(A);
P*A
%%
A = [2 3; 3 5];
 lam = eig(A)
%%
[U, Lam] = eig(A);
%%
u1 = U(:,1);
%%
A*U(:,2)-Lam(2,2)*U(:,2)
%%
B = A^2
%%
B = funm(A, @matrf)
%%
B = funm(A,'sin')
%%
sol = ode113(@oscil, [0 15], Y0);
%%
xint = 0:0.02:5;
sxint = deval(sol,xint);
plot(xint,sxint(1,:),xint,sxint(2,:))
%%
options = odeset('OutputFcn',@odeplot)
 [T,Y] = ode45(@oscil,[0 15],Y0,options);
%%
options = odeset('OutputFcn',@odephas2)
[T,Y] = ode45(@oscil,[0 15],Y0,options);
%%
[T,Y] = ode113(@syst, [0, 10], [0 1])
plot(T,Y(:,1))
%%
options = odeset('OutputFcn',@solproc)
[T,Y] = ode113(@syst, [0, 10], [0 1],options)
plot(T,Y(:,1))
%%
options = odeset('OutputFcn',@odeplot, 'OutputSel', 1)
[T,Y] = ode113(@syst, [0, 10], [0 1],options) 
%%
%������� 6.21. �������� ������� ����� �������
options = odeset('Jacobian',@JLotVol);
[T, Y] = ode23s(@LotVol, [0 100], Y0,options);
%%
sol = dde23(@ddefun, [0.5 1.5 2],@ddehistory, [0 4]);
%%
