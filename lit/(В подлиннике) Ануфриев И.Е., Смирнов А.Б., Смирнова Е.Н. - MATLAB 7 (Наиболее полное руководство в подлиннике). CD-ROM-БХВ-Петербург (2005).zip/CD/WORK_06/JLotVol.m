function J = JLotVol(t,y)
J = [0.8-0.001*y(2) -0.001*y(1)
   0.001*y(2)      -1+0.001*y(1)];
