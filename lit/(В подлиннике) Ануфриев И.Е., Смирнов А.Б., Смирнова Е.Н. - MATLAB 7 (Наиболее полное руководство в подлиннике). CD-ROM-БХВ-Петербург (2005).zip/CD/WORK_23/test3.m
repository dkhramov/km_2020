A=ones(400);
for i=1:400
    for j=1:400
        A(i,j)=A(i,j)/(i*j);
    end
end
