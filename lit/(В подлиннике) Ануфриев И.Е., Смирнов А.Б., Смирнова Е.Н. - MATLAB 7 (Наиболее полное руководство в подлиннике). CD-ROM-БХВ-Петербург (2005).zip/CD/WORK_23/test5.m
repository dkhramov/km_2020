for i=1:400
    for j=1:400
        B(i,j)=1/(i^2+j^2);
    end
end
