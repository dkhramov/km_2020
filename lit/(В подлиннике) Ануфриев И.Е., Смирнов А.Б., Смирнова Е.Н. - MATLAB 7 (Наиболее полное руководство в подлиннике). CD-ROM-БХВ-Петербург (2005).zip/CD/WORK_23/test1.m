A=ones(400);
B=5*ones(400);
for i=1:400
    for j=1:400
        A(i,j)=A(i,j)/B(i,j);
    end
end
