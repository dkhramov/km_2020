A=zeros(400);
for i=1:400
    for j=1:400
        A(i,j)=1/(i^2+j^2);
    end
end
