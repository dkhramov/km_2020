A=ones(400);
B=5*ones(400);
A=A./B;
