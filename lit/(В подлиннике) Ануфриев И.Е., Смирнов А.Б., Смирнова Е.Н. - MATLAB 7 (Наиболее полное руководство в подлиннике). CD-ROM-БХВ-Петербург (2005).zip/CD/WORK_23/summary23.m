 tic, test1, toc
%%
 tic, test2, toc
%%
A=rand(100);
save('DataFile', 'A')
B=A.^2;
save('DataFile', 'B', '-append');
clear('A', 'B')
%%
load('DataFile','A')
%%
 i8A=ones(1000,'int8');
 whos i8A
%%
 i8A(:,:)=200;
 whos i8A
%%
 i8A(1,1)
%%
 dA=ones(1000);
 sA=single(dA);
 whos dA sA
%%
 sA=zeros(1000,'single');
 sA(:,:)=0.33;
 sA=sA/2;
 sA=sA.^2;
 sA=sin(sA);
 whos sA
%%
 A=[-3 4; 9 7];
%%
 B(1,1)=-3;
 B(1,2)=4;
 B(2,1)=9;
 B(2,2)=7;
%%
 clear all
 tic, test5, toc
%%
 tic, test6, toc
%%
 tic, test5, toc
%%����� MatLab � ������� ������� ����������������
%%
 mex �setup
%%
%%
 mex mysum.f90 mysumg.f90
%%
 s=mysum(1,2)
%%
 clear mysum
%%
 mex mycsum.f90 mycsumg.f90
%%
 s=mycsum(1+2i, 3-5i)
%%
 s=mycsum(1, 3)
s =
%%
 mex mymult.f90 mymultg.f90
 A=[1 2 3; 4 5 6; 7 8 9];
 B=[1 1 0 2; 3 -1 -2 0; 5 -2 -1 2];
 C=mymult(A,B)
%%
 A*B
%%
 c=mymult(3,-7)
%%
 A=rand(400);
 B=rand(400);
%%
 tic, C=mymultfun(A,B); toc
%%
 tic, C=mymult(A,B); toc
