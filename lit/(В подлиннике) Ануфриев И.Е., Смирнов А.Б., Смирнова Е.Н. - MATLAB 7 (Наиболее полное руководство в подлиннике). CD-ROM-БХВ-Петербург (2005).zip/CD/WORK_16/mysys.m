function F = mysys(x)
F(1) = x(1)*(2-x(2))-cos(x(1))*exp(x(2));
F(2) = 2+x(1)-x(2)-cos(x(1))-exp(x(2));
