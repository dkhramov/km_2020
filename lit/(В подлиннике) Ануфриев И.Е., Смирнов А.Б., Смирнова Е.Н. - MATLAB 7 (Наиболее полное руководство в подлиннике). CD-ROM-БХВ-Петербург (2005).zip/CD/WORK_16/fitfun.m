function y = fitfun(a, x)
y = a(1)*exp(a(2)*x)+a(3)*sin(a(4)*x);
