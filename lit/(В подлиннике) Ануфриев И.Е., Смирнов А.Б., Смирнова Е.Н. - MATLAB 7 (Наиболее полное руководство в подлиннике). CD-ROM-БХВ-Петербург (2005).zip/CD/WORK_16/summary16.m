ration
%%
[x, p] = linprog(f, A, b, [], [], lb, []);
%%
risk_asset
%%
x = fmincon(@myfun, [0.7 0.7], [],[],[],[],[],[], @mycon)
%%
[x, f, flag] = fmincon(@myfun, [0.7 0.7], [],[],[],[],[],[], @mycon)
%%
x0 = [0.5; 0.2];   
[x,fval] = fseminf(@myfuns,x0,1,@sem_con)
%%
test_mm 
%%
[x,f] = fsolve(@mysys, [0 0], optimset('fsolve'))
%%
optimset('fsolve')
