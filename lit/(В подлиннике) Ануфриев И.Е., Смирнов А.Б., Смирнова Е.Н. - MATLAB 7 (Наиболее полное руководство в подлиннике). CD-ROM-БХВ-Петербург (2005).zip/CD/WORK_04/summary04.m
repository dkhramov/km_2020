>> x = 0:0.1:5;
>> f = sin(pi*x);
>> g = cos(pi*x);
>> [X, Y] = meshgrid(-1:0.05:1);
>> Z = exp(-X.^2-Y.^2).*(X-1).^2.*sin(2*pi*Y);
%%
>>  plottools

