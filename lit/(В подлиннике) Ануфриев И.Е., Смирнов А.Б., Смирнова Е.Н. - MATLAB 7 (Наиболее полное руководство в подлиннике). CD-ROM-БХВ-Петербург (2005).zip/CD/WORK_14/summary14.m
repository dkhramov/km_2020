dl = decsg(gd, sf, ns)
%%
[x,y]=mydomain(1,0.5)
%%
[p, e, t] = initmesh(dl);
%%
[p, e, t] = initmesh(dl, 'Hmax', 1.0);
pdemesh(p, e, t)
%%
char(b(7:end,:))
