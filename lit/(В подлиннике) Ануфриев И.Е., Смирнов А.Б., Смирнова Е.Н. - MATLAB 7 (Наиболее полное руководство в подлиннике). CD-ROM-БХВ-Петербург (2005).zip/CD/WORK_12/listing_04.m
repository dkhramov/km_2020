function mnGraphPlot_Callback(hObject, eventdata, handles)
btnPlot_Callback(handles.btnPlot, eventdata, handles)

function mnGraphClear_Callback(hObject, eventdata, handles)
btnClear_Callback(handles.btnClear, eventdata, handles)
